export SNPSLMD_LICENSE_FILE=28231@item0096
export PATH=/usrf01/prog/synopsys/syn/R-2020.09-SP4/bin:${PATH}
